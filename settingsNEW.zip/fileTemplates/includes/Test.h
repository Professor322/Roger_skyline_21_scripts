#set( $GG = ".fr" )
#set( $TT = "#" )
#set( $LEN = $FILENAME.length())
#set ( $SPACE = " ")
#foreach ($number in [$LEN..50])
    #set( $FILENAME = $FILENAME + $SPACE)
#end
#set( $MARVIN = " <marvin@42.fr>")
#set( $USER1 = $USER + $MARVIN)
#set( $LEN = $USER1.length())
#foreach ($number in [$LEN..42])
    #set( $USER1 = $USER1 + $SPACE)
#end
#set( $USER2 = $USER)
#set( $LEN = $USER2.length())
#foreach ($number in [$LEN..16])
    #set( $USER2 = $USER2 + $SPACE)
#end
#set( $USER3 = $USER)
#set( $LEN = $USER3.length())
#foreach ($number in [$LEN..15])
    #set( $USER3 = $USER3 + $SPACE)
#end
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   $FILENAME:+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: $USER1+#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: ${YEAR}/${MONTH}/${DAY} ${TIME}:${SECOND} by $USER2 #+#    #+#             */
/*   Updated: ${YEAR}/${MONTH}/${DAY} ${TIME}:${SECOND} by $USER3 $TT$TT$TT   $TT$TT$TT$TT$TT$TT$TT$TT$GG       */
/*                                                                            */
/* ************************************************************************** */

